//search
const searchContainer = document.getElementById('search-container');
const searchInput = document.getElementById('search-input');
const clearSearch = document.getElementById('clear-search');
const searchIcon = document.getElementById('search-icon');

searchIcon.addEventListener('click', function() {
    searchInput.classList.toggle('w-40'); 
    searchInput.focus();
});

searchInput.addEventListener('input', function() {
    clearSearch.classList.toggle('hidden', this.value === '');
});

clearSearch.addEventListener('click', function() {
    searchInput.value = '';
    searchInput.focus();
    clearSearch.classList.add('hidden');
});

//home page
let slideIndex=0;
showSlides();
function showSlides() {
    let i;
    const slides=document.getElementsByClassName("slide");
    const dots=document.getElementsByClassName("dot");
    for (i=0;i<slides.length;i++) {
        slides[i].style.opacity = "0";
        dots[i].classList.remove("bg-gray-800");
    }
    slideIndex++;
    if (slideIndex>slides.length){slideIndex = 1}
    slides[slideIndex-1].style.opacity = "1";
    dots[slideIndex-1].classList.add("bg-gray-800");
    setTimeout(showSlides, 3000); 
}
function prevSlide() {
    slideIndex--;
    showSlides();
}
function nextSlide() {
    slideIndex++;
    showSlides();
}