//search
const searchContainer = document.getElementById('search-container');
const searchInput = document.getElementById('search-input');
const clearSearch = document.getElementById('clear-search');
const searchIcon = document.getElementById('search-icon');

searchIcon.addEventListener('click', function() {
    searchInput.classList.toggle('w-40'); 
    searchInput.focus();
});

searchInput.addEventListener('input', function() {
    clearSearch.classList.toggle('hidden', this.value === '');
});

clearSearch.addEventListener('click', function() {
    searchInput.value = '';
    searchInput.focus();
    clearSearch.classList.add('hidden');
});